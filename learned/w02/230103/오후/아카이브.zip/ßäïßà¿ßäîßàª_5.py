# 5. 리스트, 반복문
string = "hello world!"

for element in string:
    print(element)
"""
예측을 작성하세요.
?
"""
# h
# e
# l
# l
# o
 
# w
# o
# r
# l
# d
# !