# 8. range, 반복문
n = 10

for element in range(1, n + 1, 3):
    print(element, end=" ")

"""
예측을 작성하세요.
?
"""
# 1 4 7 10 %