# 2. 비교 연산자
a = bool("")
b = False
print(a == b) 

#True