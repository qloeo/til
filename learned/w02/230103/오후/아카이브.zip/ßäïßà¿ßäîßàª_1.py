# 1. 비교 연산자
a = 1
b = 1
print(a < b) 

# False