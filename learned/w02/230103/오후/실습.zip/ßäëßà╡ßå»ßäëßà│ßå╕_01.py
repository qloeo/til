# 1. 정수 한 개를 입력 받고, 해당 숫자가 0 보다 큰 숫자

a = int(input('정수를 입력하세요 >'))

if a > 0 :
  print("True")
else :
  print("False")
  