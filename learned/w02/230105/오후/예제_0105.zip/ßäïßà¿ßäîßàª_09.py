# 예제_09.py
# 에러가 발생한 원인을 작성하세요.

try :
    number = 1
    if number == 1
        print(number)

except :
    print("에러가 발생했습니다.")
    print("에러의 원인은 무엇인가요?")

"""
if 에 콜론 : 이 없습니다.
"""