# 예제_04.py 
# 딕셔너리 , 반복문

dict_variable = {
    "이름" : "정우영",
    "생년월일" : "19000101",
    "회사" : "하이퍼그로스",
}

for key in dict_variable:
    print(key, dict_variable[key])

"""
이름 정우영
생년월일 19000101
회사 하이퍼그로스
"""