# 예제_06.py
# 딕셔너리
dict_variable = {
    "이름" : "정우영",
    "생년월일" : "19000101",
    "회사" : "하이퍼그로스",
}

print("나이" in dict_variable) # None -> False