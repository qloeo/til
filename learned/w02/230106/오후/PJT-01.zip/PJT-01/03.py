fruit_list = []
fruit_count = 0

with open('./data/frusits.txt', 'r') as f:
    fruits = f.readline()
    for fruit in fruits:
        fruit = fruit.strip()
        if fruit [ -5: ] == 'berry' :
            if fruit not in fruit_list:
                fruit_list.append(fruit)
                fruit_count += 1

with open('./03.txt', 'w')  as f:
    print(furit_count)
    f.write(str(fruit_count) + '\n')

    for fruit in fruit_list:
        print(fruit)
        f.write(fruit + '\n')