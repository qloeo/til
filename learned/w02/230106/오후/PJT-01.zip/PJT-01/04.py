fruit_dict = {}

with open('./data/fruist.txt','r') as f: