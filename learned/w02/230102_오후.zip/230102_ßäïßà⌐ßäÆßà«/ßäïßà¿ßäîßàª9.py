name = input('너의 이름은?')

print(name)

#