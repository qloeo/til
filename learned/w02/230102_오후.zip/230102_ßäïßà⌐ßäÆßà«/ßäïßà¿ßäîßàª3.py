string1 = 'Hello'
string2 = string1
string3 = 'World' + '!'

print(string2, '?', string3)
# Hello ? World!
