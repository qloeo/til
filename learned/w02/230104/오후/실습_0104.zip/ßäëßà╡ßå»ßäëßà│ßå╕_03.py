"""
문제 3
정수만 저장한 리스트가 주어집니다.
리스트에 저장된 정수들의 합을 출력하세요.
단, sum() 함수는 사용하지 마세요.
"""

number_list = [1, 2, 3, 4, 5]
total = 0

for number in number_list:
    total = total + number

print(total)