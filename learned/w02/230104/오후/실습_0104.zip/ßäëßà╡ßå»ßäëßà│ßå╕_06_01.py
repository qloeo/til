number_list = [1, 2, 3, 4, 5]
# cnt 변수 초기화 : 0
cnt = 0
# number_list 반복
for number in number_list:
    #cnt 값 1 씩 증가
    cnt = cnt + 1
print(cnt)