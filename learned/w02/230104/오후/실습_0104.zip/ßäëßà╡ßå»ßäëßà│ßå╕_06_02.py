number_list = [1, 2, 3, 4, 5]

# result : 0
result = 0
# number_list를 반복해서 number
for number in number_list:
    #number를 result에 더함
    result = result + number
print(result)