# 2046. 스탬프 찍기
# 주어진 숫자만큼 # 을 출력해보세요.
# 주어질 숫자는 100,000 이하다.

a = int(input())

for i in range(0,a):
    print('#',end='')